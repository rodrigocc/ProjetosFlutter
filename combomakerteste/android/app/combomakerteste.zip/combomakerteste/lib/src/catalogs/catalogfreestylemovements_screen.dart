import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class FreestyleList extends StatefulWidget {
  @override
  _FreestyleListState createState() => _FreestyleListState();
}

class _FreestyleListState extends State<FreestyleList> {

  int _current = 0;
  List imgfreestyleList = [





  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: Center(
      )

    );
  }
}
