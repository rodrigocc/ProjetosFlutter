import 'package:combomakerteste/src/login_screen.dart';
import 'package:combomakerteste/widgets/appbar.dart';
import 'package:flutter/material.dart';
import 'package:combomakerteste/widgets/bottomnavigationbar.dart';



class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: buildAppBar("Configurações"),
      bottomNavigationBar: buildBottomNavigation(context),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              backgroundColor: Colors.white,

            ),
            RaisedButton(
              color: Colors.lightBlue,
              shape: (
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25.0),
                side: BorderSide(
                  color: Colors.white,
                ),

              )
              ),
              child: Text("AJUSTES"
              ,style: TextStyle(
                  color: Colors.black
                ),),
            ),
            RaisedButton(
              color: Colors.black,
              shape: (
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0),
                    side: BorderSide(
                      color: Colors.white,
                    ),

                  )
              ),
              child: Text("SAIR"
                ,style: TextStyle(
                    color: Colors.white
                ),),
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder:(context)=>LoginScreen()));

              },
            ),

          ],
        ),
      ),
    );

  }
}
