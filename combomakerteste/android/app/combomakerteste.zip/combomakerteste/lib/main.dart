//RodrigoAsi_
import 'package:combomakerteste/src/login_screen.dart';
import 'package:flutter/material.dart';
import 'src/menu_screen.dart'; // Importando a File Criada para a classe Menu
import 'dart:async';
import 'src/splash_screen.dart';
import 'package:firebase_storage/firebase_storage.dart';

//////////////////////////////////////MAIN////////////////////////////////////////////////


void main(){

  runApp(MaterialApp(
    home: SplashPage(),
    debugShowCheckedModeBanner: false,

  ),
  );
  
}





